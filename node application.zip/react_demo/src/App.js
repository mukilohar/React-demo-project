import React, {Component, Fragment}  from 'react';
import Template from "./components/Template";

class App extends Component {
  render() {
    return (
      <Fragment>
        <Template></Template>
      </Fragment>
    )
  }
}

export default App;
